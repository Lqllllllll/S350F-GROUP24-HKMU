from django.urls import path
from .views import student_info, student_time_table, get_student_score


urlpatterns = [
    path('student_info/', student_info, name='student_info'),  # student information
    path('student_time_table/', student_time_table, name='student_time_table'),  # Student timetable
    path('get_student_score/', get_student_score, name='get_student_score'),  # student's result

]
