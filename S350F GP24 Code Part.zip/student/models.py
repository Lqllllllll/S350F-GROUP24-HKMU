from django.db import models
from django.utils import timezone
from account.models import Account


# student information sheet
class StudentInfo(models.Model):
    id = models.AutoField(primary_key=True)
    student_id = models.BigIntegerField(verbose_name="Student ID")
    name = models.CharField(max_length=255, verbose_name="Student Name")
    sex = models.CharField(max_length=10, verbose_name="Gender")
    birth_day = models.CharField(max_length=255, verbose_name="Birthday")
    native_place = models.CharField(max_length=255, verbose_name="address")
    major = models.CharField(max_length=255, verbose_name="Project")
    clazz = models.CharField(max_length=255, verbose_name='Class')
    user_id = models.ForeignKey(Account, on_delete=models.CASCADE, verbose_name="User ID")
    create_time = models.DateTimeField('save the date', default=timezone.now)
    update_time = models.DateTimeField('Modification date', default=timezone.now)
