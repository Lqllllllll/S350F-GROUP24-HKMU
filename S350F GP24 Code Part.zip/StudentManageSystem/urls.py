
from django.urls import path, re_path, include
from django.contrib import admin
# main route
urlpatterns = [
    path('admin/', admin.site.urls),  # Backend management system
    re_path(r'^', include('account.urls')),  # Account management
    re_path(r'^', include('student.urls')),  # Student module
    re_path(r'^', include('teacher.urls')),  # Teacher module
    re_path(r'^', include('manager.urls'))  # Administrator module
]

