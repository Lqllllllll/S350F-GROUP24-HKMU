from django.db import models
from django.utils import timezone


# Account Information Form
class Account(models.Model):
    Area_Level = (
        (0, 'student'),
        (1, 'teacher'),
        (2, 'manager'),
    )
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=40, null=False, verbose_name="Username", unique=True)
    password = models.CharField(max_length=512, null=False, verbose_name="Password")
    customer_type = models.IntegerField(default=0, choices=Area_Level, verbose_name="Account type")
    create_time = models.DateTimeField('save the date', default=timezone.now)
    update_time = models.DateTimeField('Modification date', default=timezone.now)
