/*
 Navicat MySQL Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 80035 (8.0.35)
 Source Host           : localhost:3306
 Source Schema         : db_students

 Target Server Type    : MySQL
 Target Server Version : 80035 (8.0.35)
 File Encoding         : 65001

 Date: 07/12/2023 04:32:08
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for account_account
-- ----------------------------
DROP TABLE IF EXISTS `account_account`;
CREATE TABLE `account_account`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(40) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `password` varchar(512) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `customer_type` int NOT NULL,
  `create_time` datetime(6) NOT NULL,
  `update_time` datetime(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of account_account
-- ----------------------------
INSERT INTO `account_account` VALUES (1, 'student1', 'pbkdf2_sha256$260000$Uoz3q4zSeHqSL7TQfNr0Kp$SnCzWBuquzEVjkXc2kRwSeESHGh84MCYt7NDmxhuxHg=', 0, '2023-10-11 10:48:37.000000', '2023-10-11 10:48:37.000000');
INSERT INTO `account_account` VALUES (2, 'teacher1', 'pbkdf2_sha256$260000$Uoz3q4zSeHqSL7TQfNr0Kp$SnCzWBuquzEVjkXc2kRwSeESHGh84MCYt7NDmxhuxHg=', 1, '2023-10-11 10:49:22.000000', '2023-10-11 10:49:22.000000');
INSERT INTO `account_account` VALUES (3, 'manager1', 'pbkdf2_sha256$260000$UwwjqczzhFTzbLkZMNSYIQ$0BD1uIWl22AohTkvGNirSXpMXbX+FHVWlEc6JPieQoE=', 2, '2023-10-11 10:50:57.000000', '2023-10-11 10:50:57.000000');

-- ----------------------------
-- Table structure for auth_group
-- ----------------------------
DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `name`(`name` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_group
-- ----------------------------

-- ----------------------------
-- Table structure for auth_group_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_group_permissions_group_id_permission_id_0cd325b0_uniq`(`group_id` ASC, `permission_id` ASC) USING BTREE,
  INDEX `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm`(`permission_id` ASC) USING BTREE,
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_group_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for auth_permission
-- ----------------------------
DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_permission_content_type_id_codename_01ab375a_uniq`(`content_type_id` ASC, `codename` ASC) USING BTREE,
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 61 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_permission
-- ----------------------------
INSERT INTO `auth_permission` VALUES (1, 'Can add log entry', 1, 'add_logentry');
INSERT INTO `auth_permission` VALUES (2, 'Can change log entry', 1, 'change_logentry');
INSERT INTO `auth_permission` VALUES (3, 'Can delete log entry', 1, 'delete_logentry');
INSERT INTO `auth_permission` VALUES (4, 'Can view log entry', 1, 'view_logentry');
INSERT INTO `auth_permission` VALUES (5, 'Can add permission', 2, 'add_permission');
INSERT INTO `auth_permission` VALUES (6, 'Can change permission', 2, 'change_permission');
INSERT INTO `auth_permission` VALUES (7, 'Can delete permission', 2, 'delete_permission');
INSERT INTO `auth_permission` VALUES (8, 'Can view permission', 2, 'view_permission');
INSERT INTO `auth_permission` VALUES (9, 'Can add group', 3, 'add_group');
INSERT INTO `auth_permission` VALUES (10, 'Can change group', 3, 'change_group');
INSERT INTO `auth_permission` VALUES (11, 'Can delete group', 3, 'delete_group');
INSERT INTO `auth_permission` VALUES (12, 'Can view group', 3, 'view_group');
INSERT INTO `auth_permission` VALUES (13, 'Can add user', 4, 'add_user');
INSERT INTO `auth_permission` VALUES (14, 'Can change user', 4, 'change_user');
INSERT INTO `auth_permission` VALUES (15, 'Can delete user', 4, 'delete_user');
INSERT INTO `auth_permission` VALUES (16, 'Can view user', 4, 'view_user');
INSERT INTO `auth_permission` VALUES (17, 'Can add content type', 5, 'add_contenttype');
INSERT INTO `auth_permission` VALUES (18, 'Can change content type', 5, 'change_contenttype');
INSERT INTO `auth_permission` VALUES (19, 'Can delete content type', 5, 'delete_contenttype');
INSERT INTO `auth_permission` VALUES (20, 'Can view content type', 5, 'view_contenttype');
INSERT INTO `auth_permission` VALUES (21, 'Can add session', 6, 'add_session');
INSERT INTO `auth_permission` VALUES (22, 'Can change session', 6, 'change_session');
INSERT INTO `auth_permission` VALUES (23, 'Can delete session', 6, 'delete_session');
INSERT INTO `auth_permission` VALUES (24, 'Can view session', 6, 'view_session');
INSERT INTO `auth_permission` VALUES (25, 'Can add account', 7, 'add_account');
INSERT INTO `auth_permission` VALUES (26, 'Can change account', 7, 'change_account');
INSERT INTO `auth_permission` VALUES (27, 'Can delete account', 7, 'delete_account');
INSERT INTO `auth_permission` VALUES (28, 'Can view account', 7, 'view_account');
INSERT INTO `auth_permission` VALUES (29, 'Can add student info', 8, 'add_studentinfo');
INSERT INTO `auth_permission` VALUES (30, 'Can change student info', 8, 'change_studentinfo');
INSERT INTO `auth_permission` VALUES (31, 'Can delete student info', 8, 'delete_studentinfo');
INSERT INTO `auth_permission` VALUES (32, 'Can view student info', 8, 'view_studentinfo');
INSERT INTO `auth_permission` VALUES (33, 'Can add teacher info', 9, 'add_teacherinfo');
INSERT INTO `auth_permission` VALUES (34, 'Can change teacher info', 9, 'change_teacherinfo');
INSERT INTO `auth_permission` VALUES (35, 'Can delete teacher info', 9, 'delete_teacherinfo');
INSERT INTO `auth_permission` VALUES (36, 'Can view teacher info', 9, 'view_teacherinfo');
INSERT INTO `auth_permission` VALUES (37, 'Can add curriculum', 10, 'add_curriculum');
INSERT INTO `auth_permission` VALUES (38, 'Can change curriculum', 10, 'change_curriculum');
INSERT INTO `auth_permission` VALUES (39, 'Can delete curriculum', 10, 'delete_curriculum');
INSERT INTO `auth_permission` VALUES (40, 'Can view curriculum', 10, 'view_curriculum');
INSERT INTO `auth_permission` VALUES (41, 'Can add major', 11, 'add_major');
INSERT INTO `auth_permission` VALUES (42, 'Can change major', 11, 'change_major');
INSERT INTO `auth_permission` VALUES (43, 'Can delete major', 11, 'delete_major');
INSERT INTO `auth_permission` VALUES (44, 'Can view major', 11, 'view_major');
INSERT INTO `auth_permission` VALUES (45, 'Can add clazz', 12, 'add_clazz');
INSERT INTO `auth_permission` VALUES (46, 'Can change clazz', 12, 'change_clazz');
INSERT INTO `auth_permission` VALUES (47, 'Can delete clazz', 12, 'delete_clazz');
INSERT INTO `auth_permission` VALUES (48, 'Can view clazz', 12, 'view_clazz');
INSERT INTO `auth_permission` VALUES (49, 'Can add student curriculum score', 13, 'add_studentcurriculumscore');
INSERT INTO `auth_permission` VALUES (50, 'Can change student curriculum score', 13, 'change_studentcurriculumscore');
INSERT INTO `auth_permission` VALUES (51, 'Can delete student curriculum score', 13, 'delete_studentcurriculumscore');
INSERT INTO `auth_permission` VALUES (52, 'Can view student curriculum score', 13, 'view_studentcurriculumscore');
INSERT INTO `auth_permission` VALUES (53, 'Can add school time table', 14, 'add_schooltimetable');
INSERT INTO `auth_permission` VALUES (54, 'Can change school time table', 14, 'change_schooltimetable');
INSERT INTO `auth_permission` VALUES (55, 'Can delete school time table', 14, 'delete_schooltimetable');
INSERT INTO `auth_permission` VALUES (56, 'Can view school time table', 14, 'view_schooltimetable');
INSERT INTO `auth_permission` VALUES (57, 'Can add clazz students', 15, 'add_clazzstudents');
INSERT INTO `auth_permission` VALUES (58, 'Can change clazz students', 15, 'change_clazzstudents');
INSERT INTO `auth_permission` VALUES (59, 'Can delete clazz students', 15, 'delete_clazzstudents');
INSERT INTO `auth_permission` VALUES (60, 'Can view clazz students', 15, 'view_clazzstudents');

-- ----------------------------
-- Table structure for auth_user
-- ----------------------------
DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE `auth_user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `last_login` datetime(6) NULL DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `first_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `last_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `email` varchar(254) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_user
-- ----------------------------
INSERT INTO `auth_user` VALUES (1, 'pbkdf2_sha256$260000$v1c9uAIVvU5XUSVYBmbAAU$wt8J6BYAQiCbNJiiJ9HBPyHP23E+PfDBNqj6khlnCK8=', '2023-10-11 10:47:50.000000', 1, 'admin', '', '', '', 1, 1, '2023-06-11 10:47:13.382460');

-- ----------------------------
-- Table structure for auth_user_groups
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_groups`;
CREATE TABLE `auth_user_groups`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_user_groups_user_id_group_id_94350c0c_uniq`(`user_id` ASC, `group_id` ASC) USING BTREE,
  INDEX `auth_user_groups_group_id_97559544_fk_auth_group_id`(`group_id` ASC) USING BTREE,
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_user_groups
-- ----------------------------

-- ----------------------------
-- Table structure for auth_user_user_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_user_permissions`;
CREATE TABLE `auth_user_user_permissions`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq`(`user_id` ASC, `permission_id` ASC) USING BTREE,
  INDEX `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm`(`permission_id` ASC) USING BTREE,
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_user_user_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for django_admin_log
-- ----------------------------
DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL,
  `object_repr` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `action_flag` smallint UNSIGNED NOT NULL,
  `change_message` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `content_type_id` int NULL DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `django_admin_log_content_type_id_c4bce8eb_fk_django_co`(`content_type_id` ASC) USING BTREE,
  INDEX `django_admin_log_user_id_c564eba6_fk_auth_user_id`(`user_id` ASC) USING BTREE,
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of django_admin_log
-- ----------------------------

-- ----------------------------
-- Table structure for django_content_type
-- ----------------------------
DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `model` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `django_content_type_app_label_model_76bd3d3b_uniq`(`app_label` ASC, `model` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of django_content_type
-- ----------------------------
INSERT INTO `django_content_type` VALUES (7, 'account', 'account');
INSERT INTO `django_content_type` VALUES (1, 'admin', 'logentry');
INSERT INTO `django_content_type` VALUES (3, 'auth', 'group');
INSERT INTO `django_content_type` VALUES (2, 'auth', 'permission');
INSERT INTO `django_content_type` VALUES (4, 'auth', 'user');
INSERT INTO `django_content_type` VALUES (5, 'contenttypes', 'contenttype');
INSERT INTO `django_content_type` VALUES (12, 'manager', 'clazz');
INSERT INTO `django_content_type` VALUES (15, 'manager', 'clazzstudents');
INSERT INTO `django_content_type` VALUES (10, 'manager', 'curriculum');
INSERT INTO `django_content_type` VALUES (11, 'manager', 'major');
INSERT INTO `django_content_type` VALUES (14, 'manager', 'schooltimetable');
INSERT INTO `django_content_type` VALUES (13, 'manager', 'studentcurriculumscore');
INSERT INTO `django_content_type` VALUES (6, 'sessions', 'session');
INSERT INTO `django_content_type` VALUES (8, 'student', 'studentinfo');
INSERT INTO `django_content_type` VALUES (9, 'teacher', 'teacherinfo');

-- ----------------------------
-- Table structure for django_migrations
-- ----------------------------
DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 24 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of django_migrations
-- ----------------------------
INSERT INTO `django_migrations` VALUES (1, 'account', '0001_initial', '2023-10-11 10:46:29.000000');
INSERT INTO `django_migrations` VALUES (2, 'contenttypes', '0001_initial', '2023-10-11 10:46:29.000000');
INSERT INTO `django_migrations` VALUES (3, 'auth', '0001_initial', '2023-10-11 10:46:30.000000');
INSERT INTO `django_migrations` VALUES (4, 'admin', '0001_initial', '2023-10-11 10:46:30.000000');
INSERT INTO `django_migrations` VALUES (5, 'admin', '0002_logentry_remove_auto_add', '2023-10-11 10:46:30.000000');
INSERT INTO `django_migrations` VALUES (6, 'admin', '0003_logentry_add_action_flag_choices', '2023-10-11 10:46:30.000000');
INSERT INTO `django_migrations` VALUES (7, 'contenttypes', '0002_remove_content_type_name', '2023-10-11 10:46:31.000000');
INSERT INTO `django_migrations` VALUES (8, 'auth', '0002_alter_permission_name_max_length', '2023-10-11 10:46:31.000000');
INSERT INTO `django_migrations` VALUES (9, 'auth', '0003_alter_user_email_max_length', '2023-10-11 10:46:31.000000');
INSERT INTO `django_migrations` VALUES (10, 'auth', '0004_alter_user_username_opts', '2023-10-11 10:46:31.000000');
INSERT INTO `django_migrations` VALUES (11, 'auth', '0005_alter_user_last_login_null', '2023-10-11 10:46:31.000000');
INSERT INTO `django_migrations` VALUES (12, 'auth', '0006_require_contenttypes_0002', '2023-10-11 10:46:31.000000');
INSERT INTO `django_migrations` VALUES (13, 'auth', '0007_alter_validators_add_error_messages', '2023-10-11 10:46:31.000000');
INSERT INTO `django_migrations` VALUES (14, 'auth', '0008_alter_user_username_max_length', '2023-10-11 10:46:31.000000');
INSERT INTO `django_migrations` VALUES (15, 'auth', '0009_alter_user_last_name_max_length', '2023-10-11 10:46:31.000000');
INSERT INTO `django_migrations` VALUES (16, 'auth', '0010_alter_group_name_max_length', '2023-10-11 10:46:31.000000');
INSERT INTO `django_migrations` VALUES (17, 'auth', '0011_update_proxy_permissions', '2023-10-11 10:46:31.000000');
INSERT INTO `django_migrations` VALUES (18, 'auth', '0012_alter_user_first_name_max_length', '2023-10-11 10:46:31.000000');
INSERT INTO `django_migrations` VALUES (19, 'teacher', '0001_initial', '2023-10-11 10:46:32.000000');
INSERT INTO `django_migrations` VALUES (20, 'student', '0001_initial', '2023-10-11 10:46:32.000000');
INSERT INTO `django_migrations` VALUES (21, 'manager', '0001_initial', '2023-10-11 10:46:33.000000');
INSERT INTO `django_migrations` VALUES (22, 'sessions', '0001_initial', '2023-10-11 10:46:33.000000');
INSERT INTO `django_migrations` VALUES (23, 'manager', '0002_auto_20231207_0111', '2023-12-06 18:47:07.021974');

-- ----------------------------
-- Table structure for django_session
-- ----------------------------
DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session`  (
  `session_key` varchar(40) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `session_data` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`) USING BTREE,
  INDEX `django_session_expire_date_a5c62663`(`expire_date` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of django_session
-- ----------------------------
INSERT INTO `django_session` VALUES ('roabyhtyqygqvieg5xfd8aiannf93xkq', 'eyJpc19sb2dpbiI6InRydWUiLCJ1c2VybmFtZSI6InN0dWRlbnQxIiwidXNlcl9pZCI6MSwiY3VzdG9tZXJfdHlwZSI6MH0:1rAyS6:e7wkAtEl7Le8UgCuTrdKG8kKILRakIguV_ge47wHDcs', '2023-12-20 20:25:02.324564');
INSERT INTO `django_session` VALUES ('ukdrrvz9fdr3rgou6q880h9esamlgsow', 'eyJpc19sb2dpbiI6InRydWUiLCJ1c2VybmFtZSI6ImJobWwiLCJ1c2VyX2lkIjoxLCJjdXN0b21lcl90eXBlIjowfQ:1q8hPO:zL2iuT9L-pw5ChHlmGcNjueCMyzqNDmObNHfxCgWik8', '2023-10-26 13:16:34.000000');
INSERT INTO `django_session` VALUES ('zcx6od3bv353rbl73pxlp8fcf5d9uq9f', 'eyJpc19sb2dpbiI6InRydWUiLCJ1c2VybmFtZSI6Im1hbmFnZXIxIiwidXNlcl9pZCI6MywiY3VzdG9tZXJfdHlwZSI6Mn0:1rAx1T:B_iJSsyff-Qivcvgg7pLaRQREju7MbO0_70G8MwWCpQ', '2023-12-20 18:53:27.962668');

-- ----------------------------
-- Table structure for manager_clazz
-- ----------------------------
DROP TABLE IF EXISTS `manager_clazz`;
CREATE TABLE `manager_clazz`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `create_time` datetime(6) NOT NULL,
  `update_time` datetime(6) NOT NULL,
  `major_id_id` bigint NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `manager_clazz_name_major_id_id_fc41b16e_uniq`(`name` ASC, `major_id_id` ASC) USING BTREE,
  INDEX `manager_clazz_major_id_id_5e5c0d3d_fk_manager_major_id`(`major_id_id` ASC) USING BTREE,
  CONSTRAINT `manager_clazz_major_id_id_5e5c0d3d_fk_manager_major_id` FOREIGN KEY (`major_id_id`) REFERENCES `manager_major` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of manager_clazz
-- ----------------------------
INSERT INTO `manager_clazz` VALUES (1, 'ENG1', '2023-10-12 13:08:41.000000', '2023-10-12 13:08:41.000000', 1);

-- ----------------------------
-- Table structure for manager_clazzstudents
-- ----------------------------
DROP TABLE IF EXISTS `manager_clazzstudents`;
CREATE TABLE `manager_clazzstudents`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_time` datetime(6) NOT NULL,
  `update_time` datetime(6) NOT NULL,
  `clazz_id_id` bigint NOT NULL,
  `student_id_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `manager_clazzstudents_student_id_id_clazz_id_id_818cea99_uniq`(`student_id_id` ASC, `clazz_id_id` ASC) USING BTREE,
  INDEX `manager_clazzstudents_clazz_id_id_e9027891_fk_manager_clazz_id`(`clazz_id_id` ASC) USING BTREE,
  CONSTRAINT `manager_clazzstudent_student_id_id_9f7a7bdb_fk_student_s` FOREIGN KEY (`student_id_id`) REFERENCES `student_studentinfo` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `manager_clazzstudents_clazz_id_id_e9027891_fk_manager_clazz_id` FOREIGN KEY (`clazz_id_id`) REFERENCES `manager_clazz` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of manager_clazzstudents
-- ----------------------------
INSERT INTO `manager_clazzstudents` VALUES (1, '2023-10-12 13:09:51.000000', '2023-10-12 13:09:51.000000', 1, 1);

-- ----------------------------
-- Table structure for manager_curriculum
-- ----------------------------
DROP TABLE IF EXISTS `manager_curriculum`;
CREATE TABLE `manager_curriculum`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `create_time` datetime(6) NOT NULL,
  `update_time` datetime(6) NOT NULL,
  `teacher_id_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `manager_curriculum_name_teacher_id_id_df8bdb95_uniq`(`name` ASC, `teacher_id_id` ASC) USING BTREE,
  INDEX `manager_curriculum_teacher_id_id_95a41a2b_fk_teacher_t`(`teacher_id_id` ASC) USING BTREE,
  CONSTRAINT `manager_curriculum_teacher_id_id_95a41a2b_fk_teacher_t` FOREIGN KEY (`teacher_id_id`) REFERENCES `teacher_teacherinfo` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of manager_curriculum
-- ----------------------------
INSERT INTO `manager_curriculum` VALUES (1, 'Engineering', '2023-10-12 13:08:59.000000', '2023-10-12 13:08:59.000000', 1);

-- ----------------------------
-- Table structure for manager_major
-- ----------------------------
DROP TABLE IF EXISTS `manager_major`;
CREATE TABLE `manager_major`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `major_code` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `name` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `create_time` datetime(6) NOT NULL,
  `update_time` datetime(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `major_code`(`major_code` ASC) USING BTREE,
  UNIQUE INDEX `name`(`name` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of manager_major
-- ----------------------------
INSERT INTO `manager_major` VALUES (1, 'CENG', 'Engineering', '2023-10-12 13:08:12.000000', '2023-10-12 13:08:12.000000');

-- ----------------------------
-- Table structure for manager_schooltimetable
-- ----------------------------
DROP TABLE IF EXISTS `manager_schooltimetable`;
CREATE TABLE `manager_schooltimetable`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `clazz_week` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `clazz_time` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `create_time` datetime(6) NOT NULL,
  `update_time` datetime(6) NOT NULL,
  `clazz_id_id` bigint NOT NULL,
  `curriculum_id` bigint NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `manager_schooltimetable_clazz_week_clazz_time_cl_5ed15f90_uniq`(`clazz_week` ASC, `clazz_time` ASC, `clazz_id_id` ASC) USING BTREE,
  INDEX `manager_schooltimetable_clazz_id_id_72168961_fk_manager_clazz_id`(`clazz_id_id` ASC) USING BTREE,
  INDEX `manager_schooltimeta_curriculum_id_fd9f91d7_fk_manager_c`(`curriculum_id` ASC) USING BTREE,
  CONSTRAINT `manager_schooltimeta_curriculum_id_fd9f91d7_fk_manager_c` FOREIGN KEY (`curriculum_id`) REFERENCES `manager_curriculum` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `manager_schooltimetable_clazz_id_id_72168961_fk_manager_clazz_id` FOREIGN KEY (`clazz_id_id`) REFERENCES `manager_clazz` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of manager_schooltimetable
-- ----------------------------
INSERT INTO `manager_schooltimetable` VALUES (1, '1', '3', '2023-10-12 13:15:14.000000', '2023-10-12 13:15:14.000000', 1, 1);
INSERT INTO `manager_schooltimetable` VALUES (2, '3', '1', '2023-10-12 13:15:23.000000', '2023-10-12 13:15:23.000000', 1, 1);
INSERT INTO `manager_schooltimetable` VALUES (3, '5', '4', '2023-10-12 13:15:30.000000', '2023-10-12 13:15:30.000000', 1, 1);

-- ----------------------------
-- Table structure for manager_studentcurriculumscore
-- ----------------------------
DROP TABLE IF EXISTS `manager_studentcurriculumscore`;
CREATE TABLE `manager_studentcurriculumscore`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `score` decimal(10, 1) NOT NULL,
  `create_time` datetime(6) NOT NULL,
  `update_time` datetime(6) NOT NULL,
  `curriculum_id_id` bigint NOT NULL,
  `student_id_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `manager_studentcurriculu_student_id_id_curriculum_149531de_uniq`(`student_id_id` ASC, `curriculum_id_id` ASC) USING BTREE,
  INDEX `manager_studentcurri_curriculum_id_id_b14ef9db_fk_manager_c`(`curriculum_id_id` ASC) USING BTREE,
  CONSTRAINT `manager_studentcurri_curriculum_id_id_b14ef9db_fk_manager_c` FOREIGN KEY (`curriculum_id_id`) REFERENCES `manager_curriculum` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `manager_studentcurri_student_id_id_9454374b_fk_student_s` FOREIGN KEY (`student_id_id`) REFERENCES `student_studentinfo` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of manager_studentcurriculumscore
-- ----------------------------
INSERT INTO `manager_studentcurriculumscore` VALUES (1, 88.0, '2023-10-12 13:16:21.000000', '2023-10-12 13:16:21.000000', 1, 1);

-- ----------------------------
-- Table structure for student_studentinfo
-- ----------------------------
DROP TABLE IF EXISTS `student_studentinfo`;
CREATE TABLE `student_studentinfo`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `sex` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `birth_day` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `native_place` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `major` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `clazz` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `create_time` datetime(6) NOT NULL,
  `update_time` datetime(6) NOT NULL,
  `user_id_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `student_studentinfo_user_id_id_b9fdaed3_fk_account_account_id`(`user_id_id` ASC) USING BTREE,
  CONSTRAINT `student_studentinfo_user_id_id_b9fdaed3_fk_account_account_id` FOREIGN KEY (`user_id_id`) REFERENCES `account_account` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of student_studentinfo
-- ----------------------------
INSERT INTO `student_studentinfo` VALUES (1, 13200001, 'Lql', 'M', '31/12/2001', 'ShaTian', 'Engineering', 'ENG1', '2023-10-12 13:09:51.000000', '2023-10-12 13:09:51.000000', 1);

-- ----------------------------
-- Table structure for teacher_teacherinfo
-- ----------------------------
DROP TABLE IF EXISTS `teacher_teacherinfo`;
CREATE TABLE `teacher_teacherinfo`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `teacher_id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `sex` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `birth_day` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `create_time` datetime(6) NOT NULL,
  `update_time` datetime(6) NOT NULL,
  `user_id_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `teacher_teacherinfo_user_id_id_e4d4518d_fk_account_account_id`(`user_id_id` ASC) USING BTREE,
  CONSTRAINT `teacher_teacherinfo_user_id_id_e4d4518d_fk_account_account_id` FOREIGN KEY (`user_id_id`) REFERENCES `account_account` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of teacher_teacherinfo
-- ----------------------------
INSERT INTO `teacher_teacherinfo` VALUES (1, 1, 'WZJ', 'M', '01/01/1995', '2023-10-11 10:50:09.000000', '2023-10-11 10:50:09.000000', 2);

SET FOREIGN_KEY_CHECKS = 1;
