from django.db import models
from django.utils import timezone
from account.models import Account


# Teacher information sheet
class TeacherInfo(models.Model):
    id = models.AutoField(primary_key=True)
    teacher_id = models.BigIntegerField(verbose_name="Teacher ID")
    name = models.CharField(max_length=255, verbose_name="Name")
    sex = models.CharField(max_length=10, verbose_name="Gender")
    birth_day = models.CharField(max_length=255, verbose_name="birth_day")
    user_id = models.ForeignKey(Account, on_delete=models.CASCADE, verbose_name="UserID")
    create_time = models.DateTimeField('save the date', default=timezone.now)
    update_time = models.DateTimeField('Modification date', default=timezone.now)