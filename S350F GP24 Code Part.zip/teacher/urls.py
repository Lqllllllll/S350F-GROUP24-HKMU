from django.urls import path
from .views import *

# Teacher sub-routing
urlpatterns = [
    path('teacher_info/', teacher_info, name='teacher_info'),  # Teacher information
    path('teacher_time_table/', teacher_time_table, name='teacher_time_table'),  # Teacher's timetable
    path('teacher_input_score/', teacher_input_score, name='teacher_input_score')  # Teacher enters scores
]
