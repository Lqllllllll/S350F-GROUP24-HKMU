from django.urls import path
from .views import *

# Administrator subrouter
urlpatterns = [
    path('manager_index/', manager_index, name='manager_index'),  # Homepage
    path('majors/', major, name='majors'),  # Project
    path('clazzs/', clazz, name='clazzs'),  # Class
    path('add_clazz/', add_clazz, name='add_clazz'),  # Add class
    path('add_major/', add_major, name='add_major'),  # Add major
    path('curriculum/', curriculum, name='curriculum'),
    path('add_curriculum/', add_curriculum, name='add_curriculum'),
    path('teachers_info/', teachers_info, name='teachers_info'),  # Teacher information
    path('add_teacher_info/', add_teacher_info, name='add_teacher_info'),  # Add teacher information
    path('add_student_info/', add_student_info, name='add_student_info'),  # Add student information
    path('change_clazz_time_table/', change_clazz_time_table, name='change_clazz_time_table'),  # Modify class schedule
    path('change_student_info/', change_student_info, name='change_student_info'),  # Modify student information
    path('change_teacher_info/', change_teacher_info, name='change_teacher_info'),  # Modify teacher information
    path('delete_student/', delete_student, name='delete_student'),  # Delete student information
    path('delete_teacher/', delete_teacher, name='delete_teacher'),  # Delete teacher information

]
