from django.utils import timezone

from django.db import models
from student.models import StudentInfo
from teacher.models import TeacherInfo


# 01Professional information sheet
class Major(models.Model):
    id = models.BigAutoField(primary_key=True)
    major_code = models.CharField(max_length=32, verbose_name='course code', unique=True)
    name = models.CharField(max_length=32, verbose_name='Project', unique=True)
    create_time = models.DateTimeField('save the date', default=timezone.now)
    update_time = models.DateTimeField('Modification date', default=timezone.now)


# 02 Class Information Sheet
class Clazz(models.Model):
    id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length=32, verbose_name='Class')
    major_id = models.ForeignKey(Major, on_delete=models.CASCADE)
    create_time = models.DateTimeField('save the date', default=timezone.now)
    update_time = models.DateTimeField('Modification date', default=timezone.now)

    class Meta:
        unique_together = ('name', 'major_id',)


# 03 Class student list
class ClazzStudents(models.Model):
    id = models.BigAutoField(primary_key=True)
    student_id = models.ForeignKey(StudentInfo, on_delete=models.CASCADE)
    clazz_id = models.ForeignKey(Clazz, on_delete=models.CASCADE)
    create_time = models.DateTimeField('save the date', default=timezone.now)
    update_time = models.DateTimeField('Modification date', default=timezone.now)

    class Meta:
        unique_together = ('student_id', 'clazz_id',)


# 04 Course Information Sheet
class Curriculum(models.Model):
    id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length=255, verbose_name='Course name')
    teacher_id = models.ForeignKey(TeacherInfo, on_delete=models.CASCADE)  # Teacher information
    create_time = models.DateTimeField('save the date', default=timezone.now)
    update_time = models.DateTimeField('Modification date', default=timezone.now)

    class Meta:
        unique_together = ('name', 'teacher_id',)


# 05 Class schedule
class SchoolTimeTable(models.Model):
    tt = (
        (1, '9:00~11:00'),
        (2, '11:00~13:00'),
        (3, '14:00~16:00'),
        (4, '16:00~18:00'),
    )
    zz = (
        (1, 'Monday'),
        (2, 'Tuesday'),
        (3, 'Wednesday'),
        (4, 'Thursday'),
        (5, 'Friday'),
    )

    id = models.BigAutoField(primary_key=True)
    curriculum = models.ForeignKey(Curriculum, on_delete=models.CASCADE)  # course information
    clazz_week = models.CharField(max_length=32, verbose_name='Day of the week class', choices=zz)
    clazz_time = models.CharField(max_length=32, verbose_name='class time', choices=tt)
    clazz_id = models.ForeignKey(Clazz, on_delete=models.CASCADE)  # Class information
    create_time = models.DateTimeField('save the date', default=timezone.now)
    update_time = models.DateTimeField('Modification date', default=timezone.now)

    class Meta:
        unique_together = ('clazz_week', 'clazz_time', 'clazz_id')


# 06 student performance table
class StudentCurriculumScore(models.Model):
    id = models.BigAutoField(primary_key=True)
    student_id = models.ForeignKey(StudentInfo, on_delete=models.CASCADE)
    curriculum_id = models.ForeignKey(Curriculum, on_delete=models.CASCADE)
    score = models.DecimalField(decimal_places=1, max_digits=10)
    create_time = models.DateTimeField('save the date', default=timezone.now)
    update_time = models.DateTimeField('Modification date', default=timezone.now)

    class Meta:
        unique_together = ('student_id', 'curriculum_id')
